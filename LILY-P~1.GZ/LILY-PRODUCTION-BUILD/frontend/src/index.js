import React from 'react';
import ReactDOM from 'react-dom/client';
import LiLyDashboard from './LiLy_Dashboard';
import './LiLy_Dashboard.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <LiLyDashboard />
  </React.StrictMode>
);
